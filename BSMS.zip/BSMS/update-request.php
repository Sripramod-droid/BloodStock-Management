<?php
session_start();
if(!isset($_SESSION['bloodbank_id'])) {
    header("Location: index.php");
    exit();
}

include "db.php";
require_once 'notify-donors.php'; // Include the donor notification functions

if(isset($_GET['id']) && isset($_GET['status'])) {
    $request_id = $conn->real_escape_string($_GET['id']);
    $status = $conn->real_escape_string($_GET['status']);
    $bloodbank_id = $_SESSION['bloodbank_id'];

    // Get request details including hospital location
    $request_query = "SELECT r.*, h.LOCATION as HOSPITAL_LOCATION 
                     FROM REQUESTS r
                     JOIN HOSPITALS h ON r.HOSPITALID = h.HOSPITALID
                     WHERE r.REQUESTID = '$request_id' 
                     AND r.BLOODBANKID = '$bloodbank_id'";
    $request_result = $conn->query($request_query);
    
    if($request_result->num_rows > 0) {
        $request = $request_result->fetch_assoc();
        
        if($status == 'Fulfilled') {
            // Check current stock
            $check_stock = "SELECT COUNT(*) as available FROM BLOODUNITS 
                           WHERE BLOODGROUP = '{$request['BLOODGROUP']}' 
                           AND STATUS = 'Available'
                           AND BLOODBANKID = '$bloodbank_id'";
            $stock_result = $conn->query($check_stock);
            $available_units = $stock_result->fetch_assoc()['available'];
            
            if($available_units >= $request['UNITS']) {
                // Enough stock - fulfill request
                $mark_used = "UPDATE BLOODUNITS 
                              SET STATUS = 'Used'
                              WHERE BLOODUNITID IN (
                                  SELECT BLOODUNITID FROM (
                                      SELECT BLOODUNITID FROM BLOODUNITS
                                      WHERE BLOODGROUP = '{$request['BLOODGROUP']}'
                                      AND STATUS = 'Available'
                                      AND BLOODBANKID = '$bloodbank_id'
                                      ORDER BY EXPIRY_DATE ASC
                                      LIMIT {$request['UNITS']}
                                  ) AS temp
                              )";
                
                if($conn->query($mark_used)) {
                    $update_request = "UPDATE REQUESTS 
                                     SET STATUS = 'Fulfilled', 
                                     TIME = NOW() 
                                     WHERE REQUESTID = '$request_id'";
                    $conn->query($update_request);
                    
                    $log_text = "Fulfilled request {$request_id} for {$request['UNITS']} units of {$request['BLOODGROUP']}";
                    logActivity($conn, $bloodbank_id, $log_text, 'USE_UNIT');
                    
                    header("Location: requests.php?success=1");
                } else {
                    header("Location: requests.php?error=update_failed");
                }
            } else {
                // First update status to show we're contacting donors
                $update_request = "UPDATE REQUESTS 
                SET STATUS = 'Insufficient Stock - Contacting Donors', 
                TIME = NOW() 
                WHERE REQUESTID = '$request_id'";
                $conn->query($update_request);

                // Redirect to show the "contacting donors" message
                header("Location: requests.php?status=contacting&request_id=$request_id");
                exit();
            }
        } else {
            // Mark as rejected
            $update_request = "UPDATE REQUESTS 
                             SET STATUS = 'Rejected' 
                             WHERE REQUESTID = '$request_id'";
            $conn->query($update_request);
            
            $log_text = "Rejected request {$request_id} for {$request['UNITS']} units of {$request['BLOODGROUP']}";
            logActivity($conn, $bloodbank_id, $log_text, 'USE_UNIT');
            
            header("Location: requests.php?success=1");
        }
    } else {
        header("Location: requests.php?error=invalid_request");
    }
} else {
    header("Location: requests.php");
}
exit();
?>